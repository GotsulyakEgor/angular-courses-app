import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-courses-component',
  templateUrl: './courses-component.component.html',
  styleUrls: ['./courses-component.component.css']
})


export class CoursesComponentComponent implements OnInit {

  constructor() {
  }

  id = 1
  title = 'course Title'
  description = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, aut corporis dolores doloribus eaque\n' +
    '      expedita\n' +
    '      explicabo harum ipsum, modi molestiae tenetur ut vel veniam voluptas voluptatem. Laudantium libero magni\n' +
    '      temporibus.'

  num = 129;
  hours = (this.num / 60);
  rhours = Math.floor(this.hours);
  minutes = (this.hours - this.rhours) * 60;
  rminutes = Math.round(this.minutes);
  finalDuration = this.rhours + "h " + this.rminutes + "min";


  creationDate: Date = new Date(1988, 3, 15)

  ngOnInit(): void {
  }

}
