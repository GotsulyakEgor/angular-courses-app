import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logo-component',
  templateUrl: './logo-component.component.html',
  styleUrls: ['./logo-component.component.css']
})
export class LogoComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
